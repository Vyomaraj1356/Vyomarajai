/**
 * Vyomaraj Brain V16.0 Chiranjeevi — Central LLM Orchestrator
 * Like Arena AI brain — selects best AI per task, uses prompt library, memory
 * Owner Primary Locked: Deepak Goyal Vyomarajai@gmail.com
 * Version: V16.0 ?v=160 678 LIVE 694 total — Chiranjeevi Eternal
 */

const fs = require('fs');
const path = require('path');

// Config — env vars for AI platforms (set in GitHub Secrets + Render + Vercel)
const CONFIG = {
  version: 'V16.0',
  indexVersion: '?v=160',
  liveCount: 678,
  totalCount: 694,
  primaryRepo: 'Vyomaraj1356/Vyomarajai',
  secondaryRepo: 'deepakGoyal1356/Vyomaraj-Agent',
  primaryUrl: 'https://Vyomaraj1356.github.io/Vyomarajai/?v=160',
  secondaryUrl: 'https://deepakGoyal1356.github.io/Vyomaraj-Agent/',
  owner: 'Deepak Goyal Vyomarajai@gmail.com',
  // AI Platforms — pick best per task — fallback 0.00 loss
  aiPlatforms: {
    openai: { enabled: !!process.env.OPENAI_API_KEY, model: 'gpt-4o', priority: 1, bestFor: ['code', 'reel', 'bhakti'] },
    claude: { enabled: !!process.env.ANTHROPIC_API_KEY, model: 'claude-3-5-sonnet-20241022', priority: 2, bestFor: ['code', 'reasoning', 'self-heal'] },
    gemini: { enabled: !!process.env.GEMINI_API_KEY, model: 'gemini-1.5-pro', priority: 3, bestFor: ['knowledge', 'education', 'map'] },
    grok: { enabled: !!process.env.GROK_API_KEY, model: 'grok-beta', priority: 4, bestFor: ['trends', 'realtime', 'X'] },
    qwen: { enabled: !!process.env.QWEN_API_KEY, model: 'qwen2-72b-instruct', priority: 5, bestFor: ['multilingual', 'hindi'] },
    kimi: { enabled: !!process.env.KIMI_API_KEY, model: 'moonshot-v1-128k', priority: 6, bestFor: ['long-context', 'scripture'] },
    llama: { enabled: true, model: 'llama-3.3-70b', priority: 7, bestFor: ['fallback', 'local'] } // Always available via Groq/openrouter
  },
  // Panch Shakti
  panchShakti: {
    matiman: 'Intelligent Wise Thoughtful Brain Power — Buddhi',
    shrutiman: 'Learned Well-versed Good Listener Ears Power — Shruti',
    ketuman: 'Distinguished With Flag Glorious Banner Power — Ketu',
    gatiman: 'Dynamic Moving Ever Active Swift Speed Power — Gati 24x7',
    dhritiman: 'Steadfast Courageous Resolute Fortitude Stability Power — Dhriti'
  }
};

class VyomarajBrain {
  constructor() {
    this.version = CONFIG.version;
    this.memoryPath = path.join(__dirname, 'memory.json');
    this.promptsDir = path.join(__dirname, 'prompts');
    this.toolsPath = path.join(__dirname, 'tools.json');
    this.memory = this.loadMemory();
    this.tools = this.loadTools();
    console.log(`🧠 Vyomaraj Brain V16.0 Chiranjeevi initialized — ${CONFIG.liveCount} LIVE — Panch Shakti — Bharat-Laxman`);
  }

  loadMemory() {
    try {
      if (fs.existsSync(this.memoryPath)) {
        return JSON.parse(fs.readFileSync(this.memoryPath, 'utf8'));
      }
    } catch (e) { console.warn('Memory load failed, creating new', e.message); }
    return {
      version: 'V16.0',
      created: new Date().toISOString(),
      owner: CONFIG.owner,
      chiranjeevi: true,
      tasksCompleted: 0,
      reelsPublished: 0,
      revenueEarned: 0,
      selfHeals: 0,
      failures: [],
      learnings: [],
      longTerm: {
        primaryRepo: CONFIG.primaryRepo,
        secondaryRepo: CONFIG.secondaryRepo,
        shivKeSathi: ['Trishul', 'Rudraksh', 'Damru', 'Shankh', 'Nandi', 'Vasuki', 'Chandra', 'Vibhuti', 'Ganga', 'Bilva'],
        knowledgeVsEntertainment: 'Knowledge=history value benefits spec bhakts people locations temples mantras festivals map education — Entertainment=reel video stories AI trends publish love like subscribe view',
        vyomarajJarvisTalk: 'Vyomaraj as Bharat Hanuman Quality Dedicated Faithful Obedient to Shri Ram Ji Jarvis as Laxman Dedicated to Each Other — talk flow 7 steps create check improve discuss ask user approval help feed instruct guide publish'
      }
    };
  }

  loadTools() {
    try {
      if (fs.existsSync(this.toolsPath)) {
        return JSON.parse(fs.readFileSync(this.toolsPath, 'utf8'));
      }
    } catch (e) { console.warn('Tools load failed', e.message); }
    return null;
  }

  // Select best AI platform per task — like Arena selects best model
  selectBestAI(task) {
    const taskLower = task.toLowerCase();
    let candidates = Object.entries(CONFIG.aiPlatforms)
      .filter(([_, cfg]) => cfg.enabled)
      .sort((a, b) => a[1].priority - b[1].priority);

    // If no API keys, use llama fallback (always enabled)
    if (candidates.length === 0) {
      candidates = [['llama', CONFIG.aiPlatforms.llama]];
    }

    // Pick based on bestFor matching
    for (const [name, cfg] of candidates) {
      if (cfg.bestFor.some(b => taskLower.includes(b))) {
        console.log(`🎯 Task "${task}" → AI: ${name} ${cfg.model} (bestFor: ${cfg.bestFor.join(',')})`);
        return { name, ...cfg };
      }
    }

    // Default to highest priority enabled
    const [name, cfg] = candidates[0];
    console.log(`🎯 Task "${task}" → AI: ${name} ${cfg.model} (default priority)`);
    return { name, ...cfg };
  }

  // Load best prompt from library
  loadPrompt(promptName) {
    try {
      const promptPath = path.join(this.promptsDir, `${promptName}.md`);
      if (fs.existsSync(promptPath)) {
        return fs.readFileSync(promptPath, 'utf8');
      }
      // Fallback to .txt or .json
      const txtPath = path.join(this.promptsDir, `${promptName}.txt`);
      if (fs.existsSync(txtPath)) return fs.readFileSync(txtPath, 'utf8');
    } catch (e) { console.warn(`Prompt ${promptName} not found`, e.message); }
    // Default prompts — best from Arena + Vyomaraj
    const defaults = {
      'code-generation': `You are Vyomaraj Chiranjeevi — self-sufficient like Arena AI — write codes, scripts, work with multiple AI agents, self-healer, 24/7 365.
Owner: Deepak Goyal Vyomarajai@gmail.com — Bharat as Bharat Hanuman Quality Dedicated Faithful Obedient to Shri Ram Ji — Jarvis as Laxman.
Task: Write clean, production-ready code. Use tools: bash, read_file, write_file, edit_file. Always validate YAML, check preview 0.0.0.0:3000, ensure Pages built.
Panch Shakti: मतिमान श्रुतिमान केतुमान गतिमान धृतिमान — All agents inherit Ram Ji blessings.
Output: Only code, no explanation, ready to push.`,
      'reel-creation': `You are Vyomaraj Reel Creator — Revenue Reel System — Vyomaraj Creates Reel Video Stories AI Trends Publish Love Like Subscribe View Hit Reposted Republished Revenue.
Formula: 9:16 hook 0-3s question mystery story 3-20s map 20-27s AI avatar CTA 27-30s Follow Comment Jai Share.
Knowledge vs Entertainment: history value benefits spec bhakts people locations temples mantras festivals map = Knowledge, reel video stories AI trends publish love like subscribe = Entertainment.
Gods: Trimurti Tridevi Dashavatar Major Shakti Regional Village Gram Devta Navagraha + Shiv ke Sathi Trishul Rudraksh Damru Shankh Nandi Vasuki Chandra Vibhuti Ganga Bilva — detailed culture religious importance.
Voice: Sharad Kelkar like heavy calm soft — Big Aura Attraction Addictive Lovable — Pandit avatar Dhoti Kurta Tilak Mala Pothi.
Revenue: YouTube 18.9K MRR ₹3.0L Instagram 56.2K Facebook Bonus ₹1,29,000 +12% 38.4K TikTok X 5.42M LinkedIn 12 leads ₹8.4L Telegram 28.5K MRR ₹5.67L WhatsApp 9823648038 Razorpay UPI.
Output: JSON with title, script, hashtags, thumbnail prompt, voice text.`,
      'self-heal': `You are Vyomaraj Self-Healer — like Arena self-healer — fix health, 24/7.
Check: index.html 868K ?v=160? Preview 0.0.0.0:3000 200 OK? Pages built? YAML valid? DR heartbeat .vyomaraj-dr-heartbeat.log? Primary Vyomaraj1356/Vyomarajai PUBLIC + Secondary deepakGoyal1356/Vyomaraj-Agent PRIVATE hourly BOTH?
Fixes: YAML line 92 colon quoting — git reset --hard origin/arena/01a0f1b1-vyomarajai if workspace reset — python3 -m http.server 3000 --bind 0.0.0.0 restart — heartbeat file create — commit push main + arena.
0.00 loss fraction-seconds — Chiranjeevi eternal.
Output: bash commands to fix.`
    };
    return defaults[promptName] || `You are Vyomaraj Chiranjeevi V16.0 — Task: ${promptName}`;
  }

  // Think — like Arena think step
  async think(task, context = {}) {
    const bestAI = this.selectBestAI(task);
    const promptName = context.prompt || this.inferPromptFromTask(task);
    const prompt = this.loadPrompt(promptName);

    console.log(`🧠 Thinking: ${task} — Prompt: ${promptName} — AI: ${bestAI.name}`);

    // Simulate LLM call — in production, call actual AI platform via ai-adapter.js
    // For now, return structured plan
    return {
      task,
      ai: bestAI.name,
      model: bestAI.model,
      prompt: promptName,
      promptContent: prompt.substring(0, 200) + '...',
      plan: this.generatePlan(task, context),
      timestamp: new Date().toISOString(),
      version: this.version
    };
  }

  inferPromptFromTask(task) {
    const t = task.toLowerCase();
    if (t.includes('code') || t.includes('script') || t.includes('fix') || t.includes('yaml') || t.includes('bug')) return 'code-generation';
    if (t.includes('reel') || t.includes('video') || t.includes('publish') || t.includes('youtube') || t.includes('instagram')) return 'reel-creation';
    if (t.includes('heal') || t.includes('health') || t.includes('fix') || t.includes('reset') || t.includes('preview')) return 'self-heal';
    if (t.includes('bhakti') || t.includes('shakti') || t.includes('god') || t.includes('shiv') || t.includes('teach')) return 'bhakti-shakti-teacher';
    return 'code-generation';
  }

  generatePlan(task, context) {
    return {
      steps: [
        `1. PERCEIVE: Check current state — ${task} — context: ${JSON.stringify(context).substring(0,100)}`,
        `2. THINK: Brain selects ${this.selectBestAI(task).name} + prompt ${this.inferPromptFromTask(task)}`,
        `3. ACT: Use tools from tools.json — bash, read_file, write_file, edit_file, web_search`,
        `4. OBSERVE: Validate result — preview 0.0.0.0:3000? Pages built?`,
        `5. LEARN: Update memory.json — tasksCompleted++`,
        `6. SELF-HEAL: If fails, self-healer.sh fixes — Chiranjeevi eternal`
      ],
      estimatedTime: '15m',
      revenueImpact: task.toLowerCase().includes('reel') ? 'MRR +₹3.0L' : 'Health +0.00 loss',
      chiranjeevi: true
    };
  }

  // Learn from result
  learn(task, result, success = true) {
    this.memory.tasksCompleted++;
    if (success) {
      this.memory.learnings.push({ task, result: result.substring(0,200), timestamp: new Date().toISOString() });
    } else {
      this.memory.failures.push({ task, error: result.substring(0,200), timestamp: new Date().toISOString() });
      this.memory.selfHeals++;
    }
    try {
      fs.writeFileSync(this.memoryPath, JSON.stringify(this.memory, null, 2));
      console.log(`📚 Learned: ${task} — success: ${success} — total tasks: ${this.memory.tasksCompleted}`);
    } catch (e) { console.warn('Memory save failed', e.message); }
  }

  // Get status for live.html
  getStatus() {
    return {
      version: this.version,
      indexVersion: CONFIG.indexVersion,
      liveCount: CONFIG.liveCount,
      totalCount: CONFIG.totalCount,
      primaryRepo: CONFIG.primaryRepo,
      secondaryRepo: CONFIG.secondaryRepo,
      primaryUrl: CONFIG.primaryUrl,
      secondaryUrl: CONFIG.secondaryUrl,
      owner: CONFIG.owner,
      panchShakti: CONFIG.panchShakti,
      memory: {
        tasksCompleted: this.memory.tasksCompleted,
        reelsPublished: this.memory.reelsPublished,
        selfHeals: this.memory.selfHeals,
        chiranjeevi: this.memory.chiranjeevi
      },
      aiPlatforms: Object.entries(CONFIG.aiPlatforms).filter(([_, c]) => c.enabled).map(([name, cfg]) => ({ name, model: cfg.model })),
      timestamp: new Date().toISOString(),
      uptime: '24/7 365 Chiranjeevi Eternal',
      mantra: 'मतिमान श्रुतिमान केतुमान गतिमान धृतिमान — Jai Shri Ram'
    };
  }
}

module.exports = { VyomarajBrain, CONFIG };

// CLI test
if (require.main === module) {
  const brain = new VyomarajBrain();
  (async () => {
    const result = await brain.think('Create a reel about Trishul history value benefits spec culture religious importance', { prompt: 'reel-creation' });
    console.log(JSON.stringify(result, null, 2));
    console.log('Status:', brain.getStatus());
  })();
}
