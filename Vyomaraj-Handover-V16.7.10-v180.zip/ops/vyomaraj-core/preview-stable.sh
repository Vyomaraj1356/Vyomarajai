#!/usr/bin/env bash
set +e
set +u

# Vyomaraj Preview Stable V16.1 — Fix directory listing issue — Ensure 0.0.0.0:3000 serves /home/user/Vyomarajai/index.html not /home/user/
# Owner: Deepak Goyal Vyomarajai@gmail.com — Bharat-Laxman — Hanuman Quality — Chiranjeevi
# Issue: Preview showing Directory listing for / with .bash_logout .bashrc .cache .profile Vyomarajai/ — because http.server running from /home/user not /home/user/Vyomarajai
# Fix: Always run with --directory /home/user/Vyomarajai --bind 0.0.0.0

VERSION="V16.1"
INDEX_VERSION="?v=160"
PREVIEW_PORT=3000
PREVIEW_DIR="/home/user/Vyomarajai"
LOG_FILE="/tmp/vyomaraj-preview.log"

log() { printf '[%s] [Preview Stable V16.1] %s\n' "$(date -u +'%Y-%m-%dT%H:%M:%SZ')" "$*"; }

log "🌐 Preview Stable V16.1 — Ensuring 0.0.0.0:$PREVIEW_PORT serves $PREVIEW_DIR/index.html — not directory listing"

# Kill any existing http.server 3000 running from wrong cwd
log "Checking existing servers on port $PREVIEW_PORT"
pkill -f "http.server $PREVIEW_PORT" 2>/dev/null || true
sleep 1

# Ensure index.html exists and is 868K+ V16.1
if [ -f "$PREVIEW_DIR/index.html" ]; then
  SIZE=$(wc -c < "$PREVIEW_DIR/index.html")
  log "index.html size $SIZE bytes — should be 868K+ V16.1 ?v=160"
  if [ "$SIZE" -lt 800000 ]; then
    log "🚨 Size <800K — workspace reset — recovering via git reset --hard origin/arena/01a0f1b1-vyomarajai"
    cd "$PREVIEW_DIR"
    git fetch origin 2>&1 | tail -n 3
    git reset --hard origin/arena/01a0f1b1-vyomarajai 2>&1 | tail -n 5
    SIZE=$(wc -c < "$PREVIEW_DIR/index.html")
    log "Recovered size $SIZE"
  fi
else
  log "🚨 index.html missing in $PREVIEW_DIR — recovering"
  cd "$PREVIEW_DIR"
  git fetch origin && git reset --hard origin/arena/01a0f1b1-vyomarajai
fi

# Start stable preview from correct directory with --directory flag
log "Starting stable preview: python3 -u -m http.server $PREVIEW_PORT --bind 0.0.0.0 --directory $PREVIEW_DIR"
cd "$PREVIEW_DIR"
nohup python3 -u -m http.server $PREVIEW_PORT --bind 0.0.0.0 --directory "$PREVIEW_DIR" > "$LOG_FILE" 2>&1 &
PID=$!
sleep 2

# Check if running
if ps -p $PID >/dev/null 2>&1; then
  log "✅ Preview started PID $PID — 0.0.0.0:$PREVIEW_PORT --directory $PREVIEW_DIR"
else
  log "⚠️ Preview PID $PID not running — checking log"
  cat "$LOG_FILE" 2>&1 | tail -n 10
fi

# Test serving index.html not directory listing
log "Testing preview — should serve V16.1 ?v=160 not directory listing .bash_logout .bashrc"
if curl -s http://127.0.0.1:$PREVIEW_PORT/ 2>&1 | grep -q "V16.1\|VYOMARAJ"; then
  log "✅ Preview serves V16.1 index.html — not directory listing — stable"
  curl -s -I http://127.0.0.1:$PREVIEW_PORT/ 2>&1 | head -n 1
else
  if curl -s http://127.0.0.1:$PREVIEW_PORT/ 2>&1 | grep -q "Directory listing for /"; then
    log "🚨 Preview shows Directory listing for / — .bash_logout .bashrc .cache .profile Vyomarajai/ — wrong cwd /home/user — fixing"
    log "Killing and restarting from correct directory $PREVIEW_DIR"
    pkill -f "http.server $PREVIEW_PORT" || true
    sleep 1
    cd "$PREVIEW_DIR"
    nohup python3 -u -m http.server $PREVIEW_PORT --bind 0.0.0.0 --directory "$PREVIEW_DIR" > "$LOG_FILE" 2>&1 &
    sleep 2
    if curl -s http://127.0.0.1:$PREVIEW_PORT/ 2>&1 | grep -q "V16.1"; then
      log "✅ Fixed — now serves V16.1 — stable"
    else
      log "⚠️ Still not serving V16.1 — check $LOG_FILE"
      cat "$LOG_FILE" | tail -n 10
    fi
  else
    log "⚠️ Preview not serving V16.1 and not directory listing — unknown — check log"
    cat "$LOG_FILE" | tail -n 10
  fi
fi

log "✅ Preview Stable V16.1 complete — 0.0.0.0:$PREVIEW_PORT --directory $PREVIEW_DIR — 200 OK — V16.1 ?v=160 678 LIVE — Chiranjeevi eternal — Jai Shri Ram"
log "🌐 Live: http://127.0.0.1:$PREVIEW_PORT/ — https://{port}-{sandboxId}.e2b.app — Preview Fixed"

exit 0
