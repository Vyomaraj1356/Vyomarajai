#!/usr/bin/env python3
"""
V16.5 Patch — User Feedback Images 1-2 (third round)
Image1 Vyomaraj color — fix color
Image2 Keep Tabs at bottom — Under Owner Law & Gate keep Rule regulations Laws IT laws Globally locally regional details for visit and review contracts etc — APK Web inherit all details there to download codes etc — Jarvis and Vyomaraj shall pick details actions updates file with scalable adaptable changes etc from here only — daily DR logs fixes healing data all here — Social Hub all social Platforms details here
"""
import pathlib, re

index_path = pathlib.Path('index.html')
html = index_path.read_text(encoding='utf-8')
print(f"Original {len(html)}")

css_v165 = """
/* V16.5 — Vyomaraj color fix + Tabs at bottom */
body { background: #0a1628 !important; color: #e5e7eb; }
.topbar-v16 { background: #0a1628 !important; border-bottom: 2px solid #f59e0b; }

/* Image1 — Vyomaraj color — Shani Blue #0a1628 background + Kuber Gold #f59e0b stable no glitter Arial */
.kuber-graffiti, .shriyantra-title, .vyomaraj-title {
  font-family: Arial, Helvetica, sans-serif !important;
  color: #f59e0b !important; /* Kuber Gold stable — no glitter */
  background: none !important;
  -webkit-background-clip: unset !important;
  background-clip: unset !important;
  text-shadow: 0 1px 0 #92400e, 0 2px 4px rgba(0,0,0,0.5), 0 0 12px rgba(245,158,11,0.4) !important;
  animation: none !important;
  letter-spacing: 0.05em;
}
.kuber-graffiti::before { display: none !important; } /* remove glitter shineSweep */
.logo-v16 { background: #0a1628 !important; border: 2px solid #f59e0b; }
.logo-v16 .v-emblem { background: #0a1628 !important; border: 2px solid #f59e0b; }
.logo-v16 .v-emblem::after { content: 'V' !important; color: #f59e0b !important; background: none !important; -webkit-background-clip: unset !important; text-shadow: 0 1px 0 #92400e, 0 0 12px rgba(245,158,11,0.6) !important; animation: none !important; }

/* Image2 — Keep Tabs at bottom — hide top tabs */
.tabs#topTabs { display: none !important; }
.bottom-tabs {
  position: fixed !important;
  bottom: 0 !important;
  left:0 !important; right:0 !important;
  z-index: 99 !important;
  background: linear-gradient(180deg, #0f2340, #0a1628) !important;
  border-top: 2px solid #f59e0b !important;
  display: flex !important;
  gap: 8px !important;
  padding: 10px 12px !important;
  overflow-x: auto !important;
  backdrop-filter: blur(12px);
  box-shadow: 0 -4px 24px rgba(0,0,0,0.5) !important;
}
.bottom-tabs .tab {
  font-size: 11px !important;
  padding: 8px 14px !important;
  border-radius: 10px !important;
  background: linear-gradient(135deg, #132a4d, #0a1628) !important;
  border: 1.5px solid #1c2f52 !important;
  color: #9fb0cc !important;
  cursor: pointer;
  flex-shrink: 0;
  transition: all 0.3s;
  white-space: nowrap;
}
.bottom-tabs .tab.active {
  background: linear-gradient(135deg, #f59e0b20, #fbbf2420) !important;
  border-color: #f59e0b !important;
  color: #ffe9a8 !important;
  box-shadow: 0 0 15px rgba(245,158,11,0.2) !important;
}
.bottom-tabs .tab:hover {
  border-color: #f59e0b !important;
  color: #ffe9a8 !important;
  transform: translateY(-1px);
}

/* Views padding for bottom tabs */
.wrap { padding-bottom: 70px !important; }

/* Sovereign Console — daily DR logs fixes healing */
.sovereign-console-log {
  background: rgba(0,0,0,0.4);
  border: 1px solid #1c2f52;
  border-radius: 8px;
  padding: 10px;
  font-size: 10px;
  font-family: 'Courier New', monospace;
  color: #9fb0cc;
  max-height: 300px;
  overflow-y: auto;
  line-height: 1.5;
}
.sovereign-card-v165 {
  background: linear-gradient(135deg, #0a1628, #132a4d);
  border: 1.5px solid #1c2f52;
  border-radius: 12px;
  padding: 14px;
  margin: 10px 0;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
}
.sovereign-card-v165 h4 { color: #f59e0b; margin: 0 0 8px 0; font-size: 13px; }
.sovereign-card-v165 ul { margin: 0; padding-left: 16px; font-size: 11px; color: #9fb0cc; line-height: 1.6; }
"""

if '</style>' in html:
    html = html.replace('</style>', css_v165 + '\n</style>', 1)
    print("✅ V16.5 CSS injected")

# Update TOP_TABS and BOTTOM_TABS to new structure — Keep Tabs at bottom
# New bottom tabs per user Image2: Sovereign Console, Owner Law & Gate, Food & Culinary Channel, Mobile & Mac APK, Sovereign Social Hub
new_bottom_tabs = """const TOP_TABS=[
{ id:'console', label:'⚡ Sovereign Console — Daily DR Logs Fixes Healing — 0.000000000 Impact' }
];
const BOTTOM_TABS=[
{ id:'console', label:'⚡ Sovereign Console — DR Logs Fixes Healing' },
{ id:'ownerlaw', label:'⚖️ Owner Law & Gate — Rules Regulations Laws IT Laws Global Local Regional Contracts' },
{ id:'food', label:'🍜 Food & Culinary Channel — Real Agents Products' },
{ id:'apk', label:'📱 Mobile & Mac APK — Web Download Codes Scalable Adaptable' },
{ id:'social', label:'👑 Sovereign Social Hub — All Social Platforms' }
];"""

# Replace old TOP_TABS and BOTTOM_TABS
html = re.sub(r'const TOP_TABS=\[.*?const BOTTOM_TABS=\[.*?\{ id:\'test\'.*?\}\n\];', new_bottom_tabs, html, flags=re.DOTALL)
print("✅ Updated TOP_TABS and BOTTOM_TABS to new bottom tabs")

# Need to ensure views exist for new ids: ownerlaw, food, apk, social
# Check existing views — we have view-console, view-agents, etc. We need to create new views if missing
# Create new views HTML
new_views_html = """
<!-- V16.5 New Views — Keep Tabs at Bottom — Owner Law & Gate, Food Culinary, APK, Social Hub -->
<div id="view-ownerlaw" class="view">
<div class="sovereign-card-v165">
<h4>⚖️ Owner Law & Gate — Rule Regulations Laws IT Laws Globally Locally Regional — Contracts — Visit and Review</h4>
<p style="font-size:11px;color:#9fb0cc">Under Owner and Law you can keep Rule regulations Laws IT laws, Globally locally regional details for visit and review contracts etc — V16.5 — Sovereign tab carries all rules regulations contracts laws — structured properly — whisperflow process — Owner Primary Locked Vyomarajai@gmail.com</p>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;margin-top:10px">
<div class="sovereign-card-v165">
<h4>📜 Global IT Laws — GDPR, DMCA, IT Act</h4>
<ul>
<li><b>IT Act 2000 India + Amendments 2008:</b> Information Technology Act — data protection, cybercrime, intermediary liability — Sovereign tab carries — IT laws globally Indian locally regional — structured properly — whisperflow process — Owner Primary Locked</li>
<li><b>GDPR EU:</b> General Data Protection Regulation — user data consent, right to be forgotten, data portability — global compliance — Sovereign — Owner Law & Gate — visit and review</li>
<li><b>DMCA US:</b> Digital Millennium Copyright Act — fair use 30 sec best scene short — transform — DISCOVER→VERIFY→SCENE PICKER — Sovereign — contracts</li>
<li><b>Contracts Global:</b> YouTube AdSense 21st, Telegram VIP 1st, Affiliate Amazon 60 days, FB/IG Bonus 21st, Brand Collab Meta Brand Collabs Manager 15th & 30th — all contracts in Owner Law & Gate tab — structured — whisperflow — visit and review</li>
</ul>
</div>
<div class="sovereign-card-v165">
<h4>⚖️ Indian Locally Regional Laws — Visit and Review</h4>
<ul>
<li><b>Indian IT Rules 2021:</b> Intermediary Guidelines — social media compliance — grievance officer — Owner Law & Gate — visit and review — Sovereign</li>
<li><b>Copyright Act 1957 India:</b> Fair dealing — 30 sec best scene — educational purpose — Sovereign tab — Owner Law & Gate</li>
<li><b>Regional:</b> Maharashtra IT policy, Pune local, Hindi Marathi content compliance — Owner Law & Gate — local regional — structured — visit and review</li>
<li><b>Whisperflow Process:</b> Use whisperflow.ai process maker aligned — flow diagram Mermaid — DISCOVER→VERIFY→SCENE→DIALOGUE→MIX→SCORE→AFFILIATE→SCHEDULE→SUBSCRIPTION→COLLAB→OWNER GATE→PUBLISH→LEARN→SYNC — Owner Law & Gate tab carries all rules regulations contracts laws — structured properly — visit and review</li>
</ul>
</div>
<div class="sovereign-card-v165">
<h4>📄 Contracts — Visit and Review — Owner Primary Locked</h4>
<ul>
<li>Owner Primary Locked Deepak Goyal Vyomarajai@gmail.com — Sovereign Root — Human-in-the-Loop Locked — Bharat as Bharat Hanuman Quality — All contracts in Owner Law & Gate — visit and review</li>
<li>Revenue Contracts: YouTube 18.9K MRR ₹3.0L, Instagram 56.2K, Facebook Bonus ₹1,29,000 +12%, Telegram 28.5K MRR ₹5.67L, WhatsApp 9823648038, Razorpay UPI, Discord 94.6K — Owner Law & Gate — contracts — visit and review</li>
<li>Brand Collab Contracts: Meta Brand Collabs Manager — 12 leads ₹8.4L — LinkedIn B2B — Owner Law & Gate — contracts — visit and review</li>
<li>Daily DR Logs: .vyomaraj-dr-heartbeat.log 13 lines — fixes healing data — Owner Law & Gate — visit and review — daily DR logs fixes healing data all here per Image2</li>
</ul>
</div>
</div>
</div>
</div>

<div id="view-food" class="view">
<div class="sovereign-card-v165">
<h4>🍜 Food & Culinary Channel — Real Agents Products — Heartbeat Links</h4>
<p style="font-size:11px;color:#9fb0cc">Food & Culinary Channel — Real agents products like Food & Culinary, Sport, Education — under them products and sub agents with heartbeat and links hyperlinks — V16.5 — Keep Tabs at bottom — Food & Culinary Channel — Beautiful user friendly</p>
<div id="foodChannelGrid" class="agents-tiles-grid"></div>
</div>
</div>

<div id="view-apk" class="view">
<div class="sovereign-card-v165">
<h4>📱 Mobile & Mac APK — Web Download Codes — Scalable Adaptable — Jarvis Vyomaraj Pick Details Actions Updates</h4>
<p style="font-size:11px;color:#9fb0cc">APK Web — inherit all details there to download, codes etc — Jarvis and Vyomaraj shall pick details, actions, updates file with scalable adaptable changes etc from here only — daily DR logs, fixes healing data all here — V16.5 — Mobile & Mac APK — Web Download Codes</p>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;margin-top:10px">
<div class="sovereign-card-v165">
<h4>📥 APK Download — Mobile & Mac — Web</h4>
<ul>
<li><b>Vyomaraj-App.apk 24M:</b> <a href="Vyomaraj-App.apk" target="_blank">Download APK 24M — Android — Mobile & Mac APK — Web Download Codes — Scalable Adaptable</a> — inherits all details there to download, codes etc — Jarvis and Vyomaraj pick details actions updates file with scalable adaptable changes etc from here only</li>
<li><b>Vyomaraj-V16.1-Final-Market-Ready.zip 28M:</b> <a href="Vyomaraj-V16.1-Final-Market-Ready.zip" target="_blank">Download ZIP 28M — Web — Mobile & Mac APK — Web Download Codes</a> — 899K index.html 43K live.html — Shriyantra Netflix tiles — Sovereign tab rules laws — beautiful user friendly</li>
<li><b>Codes:</b> ops/vyomaraj-core/brain.js, ai-adapter.js, tools.json, autonomous-loop.js, self-healer.sh, realtime-sync.sh, vyomaraj-jarvis-talk.sh, preview-stable.sh, memory.json, prompts — all codes in APK Web tab — inherit all details there to download codes etc — scalable adaptable</li>
<li><b>Web:</b> https://Vyomaraj1356.github.io/Vyomarajai/?v=160 — https://Vyomaraj1356.github.io/Vyomarajai/ops/vyomaraj-core/live.html — APK Web — inherit all details there to download codes etc</li>
</ul>
</div>
<div class="sovereign-card-v165">
<h4>🤖 Jarvis and Vyomaraj Pick Details Actions Updates File — Scalable Adaptable Changes — From Here Only</h4>
<ul>
<li>Jarvis and Vyomaraj shall pick details, actions, updates file with scalable adaptable changes etc from here only — APK Web — Mobile & Mac APK — Web Download Codes — scalable adaptable — daily DR logs fixes healing data all here per Image2</li>
<li>Actions: Perceive → Think → Act → Observe → Learn → Self-Heal — Every Minute + Every Second — 0.000000000 Business Impact — DR Sync Every Minute + Jarvis Talk Every Sec — Back Shoulder No Data Lost Keep Alive Active Earning — If one stops other keeps system working earning updates — Chiranjeevi eternal</li>
<li>Updates File: ops/vyomaraj-core/memory.json, .vyomaraj-dr-heartbeat.log, ops/vyomaraj-core/generated/reel-*.json — all updates file with scalable adaptable changes etc from here only — APK Web — Mobile & Mac APK</li>
<li>Daily DR Logs: .vyomaraj-dr-heartbeat.log 13 lines — fixes healing data — APK Web — Mobile & Mac APK — daily DR logs fixes healing data all here per Image2 — Owner Law & Gate — visit and review — Sovereign Console — DR logs</li>
</ul>
</div>
</div>
</div>
</div>

<div id="view-social" class="view">
<div class="sovereign-card-v165">
<h4>👑 Sovereign Social Hub — All Social Platforms Details Here</h4>
<p style="font-size:11px;color:#9fb0cc">Social Hub — all social Platforms details here — V16.5 — Keep Tabs at bottom — Sovereign Social Hub — All social Platforms details here — Beautiful user friendly — lighter</p>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px;margin-top:10px" id="socialHubGrid">
<!-- Social platforms injected via JS -->
</div>
</div>
</div>
"""

# Inject new views before bottomTabs
if '<div class="bottom-tabs"' in html:
    html = html.replace('<div class="bottom-tabs"', new_views_html + '\n<div class="bottom-tabs"', 1)
print("✅ New views Owner Law & Gate, Food Culinary, APK, Social Hub injected")

# Also ensure view-console is Sovereign Console with daily DR logs fixes healing data all here
sovereign_console_extra = """
<div class="sovereign-card-v165" id="sovereignConsoleDRLogs">
<h4>📜 Daily DR Logs — Fixes Healing Data All Here — Sovereign Console</h4>
<div class="sovereign-console-log" id="sovereignConsoleLog">
Loading DR logs — daily DR logs fixes healing data all here per Image2 — Owner Law & Gate — APK Web — Social Hub — Sovereign Console
</div>
</div>
"""

if 'id="view-console"' in html:
    html = html.replace('<div id="view-console" class="view active">', '<div id="view-console" class="view active">\n' + sovereign_console_extra, 1)
print("✅ Sovereign Console DR logs added")

# Update JS for new tabs and social hub and food channel
js_v165 = """
<script>
// V16.5 — Vyomaraj color fix + Tabs at bottom — Owner Law & Gate, APK Web, Social Hub, Sovereign Console
console.log('♾️ V16.5 — Image1 Vyomaraj color fix Shani Blue #0a1628 Kuber Gold #f59e0b stable Arial, Image2 Tabs at bottom Sovereign Console Owner Law & Gate Food Culinary Channel Mobile Mac APK Social Hub — Rules Regulations Laws IT Laws Global Local Regional Contracts — APK Web Download Codes — Jarvis Vyomaraj pick details actions updates file scalable adaptable — daily DR logs fixes healing — Social Hub all platforms');

// Social Hub — all social Platforms details here
const SOCIAL_PLATFORMS = [
  {name:'YouTube', icon:'📺', handle:'18.9K', mrr:'₹3.0L MRR', color:'#ff0000', link:'https://youtube.com'},
  {name:'Instagram', icon:'📸', handle:'56.2K', mrr:'Followers', color:'#e4405f', link:'https://instagram.com'},
  {name:'Facebook', icon:'👍', handle:'38.4K', mrr:'Bonus ₹1,29,000 +12%', color:'#1877f2', link:'https://facebook.com'},
  {name:'TikTok', icon:'🎵', handle:'X 5.42M', mrr:'Views', color:'#000000', link:'https://tiktok.com'},
  {name:'X Twitter', icon:'🐦', handle:'5.42M', mrr:'Views', color:'#1da1f2', link:'https://x.com'},
  {name:'LinkedIn', icon:'💼', handle:'12 leads', mrr:'₹8.4L', color:'#0077b5', link:'https://linkedin.com'},
  {name:'Telegram', icon:'✈️', handle:'28.5K', mrr:'₹5.67L MRR', color:'#0088cc', link:'https://telegram.org'},
  {name:'WhatsApp', icon:'💬', handle:'9823648038', mrr:'2B UPI Razorpay', color:'#25d366', link:'https://whatsapp.com'},
  {name:'Discord', icon:'🎮', handle:'94.6K', mrr:'Community', color:'#5865f2', link:'https://discord.com'}
];

function renderSocialHub() {
  const grid = document.getElementById('socialHubGrid');
  if(!grid) return;
  grid.innerHTML = SOCIAL_PLATFORMS.map(p => `
    <div class="agent-tile" style="border-color:${p.color}" onclick="window.open('${p.link}','_blank')" title="${p.name} — ${p.handle} — ${p.mrr} — Social Hub — All social Platforms details here">
      <div class="agent-heartbeat" style="background:${p.color};box-shadow:0 0 8px ${p.color}"></div>
      <div class="agent-icon">${p.icon}</div>
      <div class="agent-name">${p.name}</div>
      <div class="agent-count">${p.handle}</div>
      <div class="agent-count" style="color:${p.color};font-weight:700">${p.mrr}</div>
    </div>
  `).join('');
}

function renderFoodChannel() {
  const grid = document.getElementById('foodChannelGrid');
  if(!grid) return;
  const foodAgents = [
    {id:'biryani', name:'Biryani', icon:'🍛', products:12, revenue:'₹1,20,000'},
    {id:'pizza', name:'Pizza', icon:'🍕', products:8, revenue:'₹90,000'},
    {id:'sushi', name:'Sushi', icon:'🍣', products:10, revenue:'₹1,10,000'},
    {id:'curry', name:'Curry', icon:'🍛', products:14, revenue:'₹1,40,000'},
    {id:'dessert', name:'Dessert', icon:'🍰', products:6, revenue:'₹60,000'}
  ];
  grid.innerHTML = foodAgents.map(a => `
    <div class="agent-tile" onclick="handleRealAgentClick('${a.id}')" title="${a.name} — ${a.products} products — Food & Culinary Channel">
      <div class="agent-heartbeat"></div>
      <div class="agent-icon">${a.icon}</div>
      <div class="agent-name">${a.name}</div>
      <div class="agent-count">${a.products} products — ${a.revenue}</div>
    </div>
  `).join('');
}

function renderSovereignConsoleLogs() {
  const logEl = document.getElementById('sovereignConsoleLog');
  if(!logEl) return;
  // Simulate DR logs — in production fetch .vyomaraj-dr-heartbeat.log
  const logs = [
    '[2026-09-30T16:28:46Z] ✅ Sovereign Console — Daily DR Logs — Fixes Healing Data All Here — 854b0c3 built — 0.000000000 loss — Chiranjeevi',
    '[2026-09-30T16:28:32Z] ⚡ V16.2 Realtime Every Minute + Every Second — DR Sync Every Minute + Jarvis Talk Every Sec — Back Shoulder No Data Lost Keep Alive — 0.000000000 Impact',
    '[2026-09-30T16:21:59Z] ✅ DR Sync Hourly BOTH + every minute V16.2 + 30m heartbeat + real-time + every second talk — 0.00 loss — Chiranjeevi eternal',
    '[2026-09-30T15:56:11Z] ✅ Secondary PRIVATE via PAT UP — deepakGoyal1356/Vyomaraj-Agent — vyomaraj-sync-both success 16s — 0.00 loss',
    '[2026-09-30T15:40:00Z] ⚠️ YAML invalid line 92 mapping values not allowed — Fixed by quoting — YAML OK — success 16s',
    '[2026-09-30T16:33:00Z] ✅ Preview Fixed — Directory listing for / .bash_logout .bashrc .cache .profile Vyomarajai/ — root cause http.server from /home/user not /home/user/Vyomarajai — fixed via --directory flag — PID 1486 0.0.0.0:3000 200 OK 945K',
    '[2026-09-30T16:54:26Z] ✅ V16.3 Shriyantra Netflix Tiles — Image1 Dummy Revenue, Image2 Shani Blue Kuber Gold Arial V as Laxman Jarvis, Image3 Remove punch-line, Image4 Top Right Tiles Clickable, Image5 Heartbeat Background, Image6 Small Button Right, Image7 Manage Banks hidden, Image8 Sovereign Tab Bottom, Image9 Remove Sovereign Root, Image10 Shriyantra Netflix Tiles, Image11 Sovereign Rules Laws Whisperflow — Preview Stable PID 1486 0.0.0.0:3000 200 OK 920K',
    '[2026-09-30T17:20:57Z] ✅ V16.4 Shriyantra Fit Stable + Real Agents + Kuber Dashboard Per Agent + Cinema Nostalgia — DR Tiles Small Right Corner, Shriyantra Fit Stable Watch Calendar Middle, Real Agents Food Culinary Sport Education Kuber Dashboard Revenue Per Agent Daily Weekly Monthly Quarterly Yearly, Cinema Nostalgia Wooden Framework Approvals Shutter Dolly Sound Approve Hold Reject Voice Feedback Logs Audit, Clean Up Data To Agents Sovereign Tab Beautiful User Friendly — Preview Stable PID 1408 0.0.0.0:3000 200 OK 924K — 0.000000000 Impact'
  ];
  logEl.innerHTML = logs.map(l => `<div style="padding:4px 0;border-bottom:1px solid rgba(28,47,82,0.3)">${l}</div>`).join('');
}

// Initialize V16.5
document.addEventListener('DOMContentLoaded', () => {
  renderSocialHub();
  renderFoodChannel();
  renderSovereignConsoleLogs();
});

renderSocialHub();
renderFoodChannel();
renderSovereignConsoleLogs();

console.log('✅ V16.5 Initialized — Vyomaraj color Shani Blue Kuber Gold stable Arial, Tabs at bottom Sovereign Console Owner Law & Gate Food Culinary Channel Mobile Mac APK Social Hub — Owner Law Rules Regulations Laws IT Laws Global Local Regional Contracts — APK Web Download Codes — Jarvis Vyomaraj pick details actions updates scalable adaptable — daily DR logs fixes healing — Social Hub all platforms — 0.000000000 Impact — Chiranjeevi Eternal');
</script>
"""

if '</body>' in html:
    html = html.replace('</body>', js_v165 + '\n</body>')
print("✅ V16.5 JS injected")

# Update version marker
html = html.replace('V16.4 SHRIYANTRA', 'V16.5 SHRIYANTRA — Vyomaraj Color Fix + Tabs Bottom — Sovereign Console Owner Law Gate Food Culinary APK Social Hub — 0.000000000 Impact')
print(f"New size {len(html)}")
index_path.write_text(html, encoding='utf-8')
print(f"✅ Written index.html V16.5 — {len(html)} bytes")
