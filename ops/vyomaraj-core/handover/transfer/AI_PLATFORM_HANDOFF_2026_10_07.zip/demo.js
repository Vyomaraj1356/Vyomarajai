'use strict';
const $ = id => document.getElementById(id);
let lastPlan = null;
const recipeOptions = {
  bhakti: [{id: 'fruit', label: 'Fruit offering (illustrative)'}, {id: 'coconut', label: 'Coconut offering (illustrative)'}, {id: 'yogurt', label: 'Yogurt offering (illustrative)'}],
  'liquor-bar': [{id: 'chana', label: 'Chana snack (illustrative)'}]
};
function option(label, value) {
  const node = document.createElement('option');
  node.textContent = label; node.value = value;
  return node;
}
function setStatus(message, state) {
  $('plan-status').textContent = message;
  $('plan-status').dataset.state = state || 'info';
}
function updateRecipes() {
  const select = $('recipe-id');
  select.replaceChildren(option('No recipe', ''));
  for (const recipe of recipeOptions[$('experience').value] || []) {
    select.append(option(recipe.label, recipe.id));
  }
}
function addSummary(label, value) {
  const box = document.createElement('div'); box.className = 'summary-item';
  const caption = document.createElement('span'); caption.textContent = label;
  const text = document.createElement('strong'); text.textContent = String(value ?? '—');
  box.append(caption, text); return box;
}
function renderPlan(plan) {
  lastPlan = plan;
  const summary = $('plan-summary'); summary.replaceChildren(
    addSummary('Status', plan.status),
    addSummary('Experience / category', `${plan.experience} / ${plan.category_id}`),
    addSummary('Topic', plan.topic?.title || plan.topic?.id),
    addSummary('Provider / AI calls', `${plan.provider ?? 'none'} / ${plan.ai_calls_made}`),
    addSummary('Publication', plan.publishing_enabled ? 'enabled' : 'not enabled'),
    addSummary('Production', plan.production_deployed ? 'deployed' : 'not deployed'),
  );
  const sources = $('sources'); sources.replaceChildren();
  for (const source of plan.source_references || []) {
    const item = document.createElement('li');
    const name = source.title || source.name || source.id || 'Reference';
    const url = source.url || source.source_url;
    if (typeof url === 'string') {
      try {
        const parsed = new URL(url);
        if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
          const link = document.createElement('a');
          link.textContent = name; link.href = parsed.href;
          link.target = '_blank'; link.rel = 'noopener noreferrer'; item.append(link);
        } else item.textContent = name;
      } catch (_) { item.textContent = name; }
    } else item.textContent = name;
    sources.append(item);
  }
  if (!sources.children.length) sources.append(Object.assign(document.createElement('li'), {textContent: 'No source references in this plan.'}));
  const gates = $('gates'); gates.replaceChildren();
  for (const gate of plan.review_gates || []) {
    const item = document.createElement('li'); item.textContent = gate; gates.append(item);
  }
  $('plan-json').textContent = JSON.stringify(plan, null, 2);
  $('result').hidden = false;
  $('result').scrollIntoView({behavior: 'smooth', block: 'start'});
}
$('experience').addEventListener('change', updateRecipes);
$('plan-form').addEventListener('submit', async event => {
  event.preventDefault();
  const button = $('plan-button'); button.disabled = true;
  $('result').hidden = true;
  const body = {
    experience: $('experience').value,
    topic_id: $('topic-id').value.trim() || 'overview',
    mode: $('mode').value,
    diet: $('diet').value,
  };
  if ($('recipe-id').value) body.recipe_id = $('recipe-id').value;
  setStatus('Building a deterministic local plan. No provider or external service is being called…', 'info');
  try {
    const response = await fetch('/api/plan', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(body), cache: 'no-store',
    });
    let result;
    try { result = await response.json(); }
    catch (_) { throw new Error('This page is static-only here. Open the sandbox preview server that provides the bounded local planner API.'); }
    if (!response.ok) throw new Error(result.error || 'Plan could not be built.');
    renderPlan(result);
    setStatus('Local plan created. It was not saved, sent to an agent, published, or deployed.', 'success');
  } catch (error) {
    setStatus(`Planner unavailable: ${error.message}`, 'error');
  } finally {
    button.disabled = false;
  }
});
$('copy-json').addEventListener('click', async () => {
  if (!lastPlan) return;
  try {
    await navigator.clipboard.writeText(JSON.stringify(lastPlan, null, 2));
    $('copy-json').textContent = 'Copied';
    setTimeout(() => {$('copy-json').textContent = 'Copy JSON';}, 1200);
  } catch (_) {
    setStatus('Clipboard permission is unavailable in this browser; expand the JSON view and copy manually.', 'error');
  }
});
updateRecipes();
