# VYOMARAJ — RUNBOOK: CONFIGURE · INTEGRATE · INHERIT · VERIFY

Generated 2026-10-07 08:16 UTC. The procedure for running this project, in the order it should be done. Copy-pasteable. Every command is run from the repository root.

---

## A · Safe preview posture

The 7 October 06:11 UTC live-wiring result is a historical point-in-time check. The unauthenticated gateway and lane studios on 4176/4181/4182 were stopped after route checks. A follow-up port/process probe at 08:15 UTC found no listener on 3000, 4174, 4176, 4181 or 4182. These preview processes are not production services.

**Do not restart the gateway or studios on a publicly reachable `0.0.0.0` preview.** Before any interactive service is exposed, add owner-approved authentication, authorization, CSRF protection for writes, audit logging, and network restrictions; test in an isolated workspace with disposable data. Bind loopback when the server supports it. Stop every test process when verification finishes. A live preview is not deployment or security evidence.

The product/report servers are Python standard-library applications in this checkout. The reports viewer exposes a read-only allowlisted surface; gateway/studio endpoints may mutate local state and must be treated as write-capable until independently audited.

---

## B · Verify (run this before trusting anything)

The offline gate is safe to run now. Live route verifiers require an explicitly secured, isolated test stack; the unauthenticated gateway/lane processes were stopped and must not be restarted on the public preview.

```bash
python3 ops/vyomaraj-core/handover/run_offline_suites.py --ci   # tests, node checks, builders
# Optional only in a secured, isolated test environment:
python3 ops/vyomaraj-core/handover/verify_live_wiring.py       # explicit test ports only
python3 ops/vyomaraj-core/handover/verify_preview.py           # page contracts + packages
python3 ops/vyomaraj-core/handover/realtime_status.py          # local port probe as JSON
python3 ops/vyomaraj-core/handover/probes.py --once             # manual, fixed-loopback snapshot
```

`probes.py --once` appends to `/tmp/vyomaraj-probes.jsonl` and atomically writes `/tmp/vyomaraj-probes.latest.json`; `/reports/monitor` reads that latest file and never starts a probe. This is a local manual preview check, not scheduled or production monitoring, alerting, replication-lag, backup, or independent-site DR.

A missing live listener means the live preview is unavailable, not production failure or success. Do not restart an unauthenticated writer just to make a verifier green; first secure the test environment, then record the exact ports and scope.

---

## C · Regenerate the evidence after any change

Order matters. Refresh only generated status reports; preserve frozen transfer archives and historical packages unless the owner explicitly approves a new archive.

```bash
python3 ops/vyomaraj-core/handover/build_issue_ledger.py
python3 ops/vyomaraj-core/handover/build_stack_record.py
python3 ops/vyomaraj-core/handover/architecture_diagram.py
python3 ops/vyomaraj-core/handover/build_market_readiness.py
python3 ops/vyomaraj-core/handover/build_go_live_brief.py
python3 ops/vyomaraj-core/handover/build_full_handover.py
python3 ops/vyomaraj-core/handover/build_ai_handoff.py
python3 ops/vyomaraj-core/handover/run_offline_suites.py --ci
```

Each report builder also supports `--check`, which fails if its checked-in copy has drifted. Do not rebuild frozen archives as part of a status refresh.

---

## D · Configure a real thing (procedure that has worked here)

1. **Measure first.** Probe the current state; never assume.
2. **Write the smallest checkable artifact** — JSON or Markdown — that states the new fact.
3. **Add a `--check`** so the artifact cannot silently drift.
4. **Gate it** by adding the command to `run_offline_suites.py`.
5. **Wire it** to a read-only surface by default; any writer needs owner-approved authentication, authorization, CSRF protection, audit logging and a restricted network boundary first.
6. **Add it to the verifier's required files** so a missing file is a failure.
7. Run offline gates. Use live verifiers only in an explicitly secured isolated test environment; never restart unauthenticated writer services on a public preview.

This is why the project can be trusted: every claim has a command that fails when the claim stops being true.

---

## E · Integrate with a platform (the honest sequence)

| Step | Do this | Cost |
|---|---|---|
| 1 | Publish by hand from the owner's own account | ₹0 |
| 2 | Add a contact address to the page so a viewer can reach the owner | ₹0 |
| 3 | Add a free analytics counter and confirm it records a visit | ₹0 |
| 4 | Grow the audience until the platform's own threshold is met | ₹0 |
| 5 | Only then request API access for automation | ₹0, needs review |
| 6 | Only after earnings: host, domain, payments, vendors | paid |

Do not build a publisher before there is published content — and do not promise a platform integration in any document until an API call exists in code with a credential behind it.

---

## F · Inherit content correctly

| Take | Leave |
|---|---|
| The format: how a Sufi/qawwali or ghazal performance is structured and credited | The recording, the lyrics, the melody |
| The studio-show shape: house band, guest pairing, one episode one story | The show's name, branding or episode content |
| The documentation habit: name every creator, record every source | Any claim of endorsement by a named artist |

The test that enforces this in the repository fails the build if inherited titles, lyrics or artwork are copied in.

---

## G · Recover, hand over, and protect

- **Hand over:** `build_full_handover.py` and `build_ai_handoff.py` produce the documents and the downloadable archives. Both are safe to share: no token, no credential, no environment file, and the owner's email is redacted in the AI-facing one.
- **Back up:** a GitHub Actions `verify-or-sync` workflow and historical match records exist. As of the 7 October read, the exact secondary target/Actions access cannot be verified (404/403), and no new replication was triggered. Treat current DR synchronization as **UNVERIFIED** until an owner-authorized fresh run records a matching tree and rollback parent. Even when working, it covers tracked files only, not runtime state.
- **Protect:** the reports viewer serves an allowlist only and sends a hardened `Content-Security-Policy`. Same-origin images are permitted (`img-src 'self'`); scripts and external hosts are not.

---

## H · Owner-gated steps before any release or earning claim

1. **Unblock issue #6 safely:** owner/admin confirms the exact existing secondary and authorizes minimum read/Actions access; then recheck read-only and verify a fresh matching snapshot. Keep issue #6 open until its current acceptance criteria are evidenced.
2. **Verify the existing APK** with `apksigner verify`, review signer provenance and install it on a real Android device. If verification fails or provenance is unknown, recover the original source, rebuild and sign with an owner-held key; otherwise leave it off the release page.
3. **Review branch scope and deployment:** obtain explicit owner approval before any PR merge or Pages deployment; this branch is not currently deployed.
4. **Publish a contact address** on the public page and **switch on analytics** only after owner account decisions; confirm one real visit is recorded.

Then hand-publish the first episodes and apply to the YouTube Partner Program **before 1 February 2027** — the threshold for new applicants rises to 8,000 watch hours that day, from 4,000 today. The 500-subscriber tier opens fan funding earlier at 3,000 hours.

---

## I · Known limits, stated so nobody is surprised

| Limit | Consequence |
|---|---|
| Preview links are session-scoped | all checked listeners on 3000/4174/4176/4181/4182 were closed at 08:15 UTC; Pages is durable but currently serves `main` only |
| `flow-diagram.html` loads Mermaid from a CDN | on a network that blocks that CDN, the diagrams do not render |
| No analytics | nobody can see visits |
| No login | no returning audience |
| No payments | nothing can be sold |
| DR covers files, not runtime | a live database would not be covered |

