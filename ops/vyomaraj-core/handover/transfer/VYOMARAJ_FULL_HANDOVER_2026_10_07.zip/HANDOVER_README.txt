Vyomaraj full handover archive.
Open VYOMARAJ_FULL_HANDOVER_2026_10_06.md first: it is the index to everything else.
The shared temporal-knowledge contract and resolver are in the config/knowledge, docs/architecture and ops/shriyantra paths.
No credentials, tokens or environment files are included.
