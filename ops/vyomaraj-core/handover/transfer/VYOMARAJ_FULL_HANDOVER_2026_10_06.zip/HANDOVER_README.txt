Vyomaraj full handover archive.
Open VYOMARAJ_FULL_HANDOVER_2026_10_06.md first: it is the index to everything else.
No credentials, tokens or environment files are included.
